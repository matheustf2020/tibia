function onUse(cid, item, fromPosition, itemEx, toPosition)
	return TOOLS.SCYTHE(cid, item, fromPosition, itemEx, toPosition, true)
end
